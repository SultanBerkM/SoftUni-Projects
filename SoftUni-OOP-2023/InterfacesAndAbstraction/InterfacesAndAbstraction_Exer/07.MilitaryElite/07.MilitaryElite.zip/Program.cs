﻿using _07.MilitaryElite.Core;
using System;

namespace _07.MilitaryElite
{
    public class Program
    {
        static void Main(string[] args)
        {

            Engine engine = new Engine();
            engine.Run();
        }
    }
}
