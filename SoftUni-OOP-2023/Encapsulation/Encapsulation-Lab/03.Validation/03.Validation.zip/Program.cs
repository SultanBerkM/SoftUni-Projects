﻿using System;

namespace PersonsInfo
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new Person("Berk", "Mehmed", -6, 2000m);
        }
    }
}
